#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "studentLL.h"
#include "studentRecord.h"

// linked list node type
// DO NOT CHANGE
typedef struct node {
    studentRecordT data;
    struct node    *next;
} NodeT;

// linked list type
typedef struct ListRep {
   NodeT *head;

/* Add more fields if you wish */

} ListRep;

/*** Your code for stages 2 & 3 starts here ***/

// Time complexity: 
// Explanation: 
List newLL() {

   return NULL;  /* needs to be replaced */
}

// Time complexity: 
// Explanation: 
void dropLL(List listp) {

   return;  /* needs to be replaced */
}

// Time complexity: 
// Explanation: 
void inLL(List listp, int zid) {

   return;  /* needs to be replaced */
}

// Time complexity: 
// Explanation: 
void insertLL(List listp, int zid, int cr, float wam) {

   return;  /* needs to be replaced */
}

// Time complexity: 
// Explanation: 
void getStatLL(List listp, int *n, float *wam, float *w_wam) {

   return;  /* needs to be replaced */
}

// Time complexity: 
// Explanation: 
void showLL(List listp) {

   return;  /* needs to be replaced */
}
